// Define the base URL for the API
const baseUrl = 'http://localhost:3030/jsonstore/tasks/';

// Get references to the HTML elements
const nameInput = document.getElementById('name');
const daysInput = document.getElementById('num-days');
const dateInput = document.getElementById('from-date');
const addBtn = document.getElementById('add-vacation');
const editBtn = document.getElementById('edit-vacation');
const loadBtn = document.getElementById('load-vacations');
const listDiv = document.getElementById('list');

let editId = null; // To store the id of the vacation being edited

// Add event listeners
addBtn.addEventListener('click', addVacation);
editBtn.addEventListener('click', editVacation);
loadBtn.addEventListener('click', loadVacations);

function createVacationElement(vacation) {
    const div = document.createElement('div');
    div.className = 'container';
    div.innerHTML = `
        <h2>${vacation.name}</h2>
        <h3>${vacation.date}</h3>
        <h3>${vacation.days}</h3>
        <button class="change-btn">Change</button>
        <button class="done-btn">Done</button>
    `;
    div.querySelector('.change-btn').addEventListener('click', () => changeVacation(vacation._id));
    div.querySelector('.done-btn').addEventListener('click', () => deleteVacation(vacation._id));
    return div;
}

function addVacation() {
    const newVacation = {
        name: nameInput.value,
        days: daysInput.value,
        date: dateInput.value
    };
    fetch(baseUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newVacation)
    })
    .then(response => response.json())
    .then(() => {
        nameInput.value = '';
        daysInput.value = '';
        dateInput.value = '';
        loadVacations();
    });
}

function editVacation() {
    const updatedVacation = {
        name: nameInput.value,
        days: daysInput.value,
        date: dateInput.value
    };
    fetch(baseUrl + editId, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedVacation)
    })
    .then(response => response.json())
    .then(() => {
        nameInput.value = '';
        daysInput.value = '';
        dateInput.value = '';
        editId = null;
        addBtn.disabled = false;
        editBtn.disabled = true;
        loadVacations();
    });
}

function loadVacations() {
    fetch(baseUrl)
    .then(response => response.json())
    .then(data => {
        listDiv.innerHTML = '';
        Object.values(data).forEach(vacation => {
            listDiv.appendChild(createVacationElement(vacation));
        });
    });
}

function changeVacation(id) {
    fetch(baseUrl + id)
    .then(response => response.json())
    .then(vacation => {
        nameInput.value = vacation.name;
        daysInput.value = vacation.days;
        dateInput.value = vacation.date;
        editId = id;
        addBtn.disabled = true;
        editBtn.disabled = false;
    });
}

function deleteVacation(id) {
    fetch(baseUrl + id, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(() => {
        loadVacations();
    });
}
