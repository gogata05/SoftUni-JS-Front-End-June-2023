const API_URL = 'http://localhost:3030/jsonstore/tasks';
const loadBtn = document.getElementById('load-course');
const addBtn = document.getElementById('add-course');
const editBtn = document.getElementById('edit-course');
const list = document.getElementById('list');
let courseIdToEdit = null;

loadBtn.addEventListener('click', loadCourses);
addBtn.addEventListener('click', addCourse);
editBtn.addEventListener('click', editCourse);

async function loadCourses() {
  list.innerHTML = '';
  const response = await fetch(API_URL);
  const courses = await response.json();

  for (const id in courses) {
    const course = courses[id];
    const courseDiv = createCourseDiv(course, id);
    list.appendChild(courseDiv);
  }
}

function createCourseDiv(course, id) {
  const container = document.createElement('div');
  container.className = 'container';
  container.innerHTML = `
    <h2>${course.title}</h2>
    <h3>${course.teacherName}</h3>
    <h3>${course.type}</h3>
    <h4>${course.description}</h4>
  `;

  const editBtn = document.createElement('button');
  editBtn.className = 'edit-btn';
  editBtn.textContent = 'Edit Course';
  editBtn.addEventListener('click', () => populateFormForEditing(course, id));
  container.appendChild(editBtn);

  const finishBtn = document.createElement('button');
  finishBtn.className = 'finish-btn';
  finishBtn.textContent = 'Finish Course';
  finishBtn.addEventListener('click', () => finishCourse(id));
  container.appendChild(finishBtn);

  return container;
}

async function addCourse(event) {
  event.preventDefault();

  const title = document.getElementById('course-name').value;
  const type = document.getElementById('course-type').value;
  const description = document.getElementById('description').value;
  const teacherName = document.getElementById('teacher-name').value;

  const response = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, type, description, teacherName }),
  });

  clearFormFields();
  loadCourses();
}

function clearFormFields() {
  document.getElementById('course-name').value = '';
  document.getElementById('course-type').value = '';
  document.getElementById('description').value = '';
  document.getElementById('teacher-name').value = '';
}

function populateFormForEditing(course, id) {
  document.getElementById('course-name').value = course.title;
  document.getElementById('course-type').value = course.type;
  document.getElementById('description').value = course.description;
  document.getElementById('teacher-name').value = course.teacherName;

  courseIdToEdit = id;
  addBtn.disabled = true;
  editBtn.disabled = false;
}

async function editCourse(event) {
  event.preventDefault();

  const title = document.getElementById('course-name').value;
  const type = document.getElementById('course-type').value;
  const description = document.getElementById('description').value;
  const teacherName = document.getElementById('teacher-name').value;

  const response = await fetch(`${API_URL}/${courseIdToEdit}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, type, description, teacherName }),
  });

  clearFormFields();
  addBtn.disabled = false;
  editBtn.disabled = true;
  courseIdToEdit = null;
  loadCourses();
}

async function finishCourse(id) {
  const response = await fetch(`${API_URL}/${id}`, {
    method: 'DELETE',
  });

  loadCourses();
}
